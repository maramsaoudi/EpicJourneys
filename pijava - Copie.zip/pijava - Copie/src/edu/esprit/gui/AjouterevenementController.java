package edu.esprit.gui;

import edu.esprit.entities.Evenement;
import edu.esprit.services.EvenementCrud;
import edu.esprit.utils.MyConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class AjouterevenementController implements Initializable {
    @FXML
    private TextField id_titre;
    @FXML
    private TextField id_type;
    @FXML
    private TextField id_destination;
    @FXML
    private TextArea id_description;
    @FXML
    private DatePicker id_date;
    @FXML
    private ComboBox<Integer> id_guide;
    @FXML
    private ComboBox<String> id_sponsor;
    @FXML
    private Spinner<Integer> id_prix;
    @FXML
    private Button btnajouter;
    @FXML
    private TextField id_image;
    
  private Stage primaryStage;

public void setPrimaryStage(Stage primaryStage) {
    this.primaryStage = primaryStage;
}

 

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Récupérez les guides
        populateGuideComboBox();

        // Récupérez les sponsors
        populateSponsorComboBox();
        
        // Initialiser le spinner
        SpinnerValueFactory<Integer> valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10000, 1, 1);
        valueFactory.setValue(1);
        id_prix.setValueFactory(valueFactory);
    }

    private void populateGuideComboBox() {
        try {
            MyConnection myConnection = MyConnection.getInstance();
            Connection dbConnection = myConnection.getCnx();

            Statement statement = dbConnection.createStatement();
            ResultSet resultSetGuideIds = statement.executeQuery("SELECT id FROM user WHERE role = 'GUIDE'");

            ObservableList<Integer> guideIds = FXCollections.observableArrayList();

            while (resultSetGuideIds.next()) {
                guideIds.add(resultSetGuideIds.getInt("id"));
            }

            id_guide.setItems(guideIds);

            resultSetGuideIds.close();
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
            // Gérer les exceptions ici
        }
    }

    private void populateSponsorComboBox() {
        try {
            MyConnection myConnection = MyConnection.getInstance();
            Connection dbConnection = myConnection.getCnx();

            Statement statement = dbConnection.createStatement();
            ResultSet resultSetSponsorNames = statement.executeQuery("SELECT nomSponsor FROM sponsor");

            ObservableList<String> sponsorNames = FXCollections.observableArrayList();

            while (resultSetSponsorNames.next()) {
                sponsorNames.add(resultSetSponsorNames.getString("nomSponsor"));
            }

            id_sponsor.setItems(sponsorNames);

            resultSetSponsorNames.close();
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
            // Gérer les exceptions ici
        }
    }

   @FXML
private void saveEvenement(ActionEvent event) {
    String titre = id_titre.getText();
    String type = id_type.getText();
    String destination = id_destination.getText();
    String description = id_description.getText();
    String image = id_image.getText();

    Date date = null;
    if (id_date.getValue() != null) {
        date = java.sql.Date.valueOf(id_date.getValue());
    }

    Integer guide = id_guide.getValue(); // Récupérer l'ID du guide sélectionné
    String sponsor = id_sponsor.getValue(); // Récupérer le nom du sponsor sélectionné
    Integer prix = id_prix.getValue();

    Evenement e = new Evenement(type, date, description, destination, guide, image, prix, titre, sponsor);
    EvenementCrud ec = new EvenementCrud();

    ec.ajouterEvenement(e);
    
    // Close the initial table view
    Stage currentStage = (Stage) id_titre.getScene().getWindow();
    currentStage.close();

    // Switch to the new TableView scene
    switchToTableViewScene();
}

@FXML
private void switchToTableViewScene() {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("tableviewevents.fxml"));
        Parent tableViewRoot = loader.load();

        Scene tableViewScene = new Scene(tableViewRoot);

        Stage primaryStage = new Stage(); // Create a new stage for the TableView scene
        primaryStage.setScene(tableViewScene);

        primaryStage.show();
    } catch (IOException e) {
        e.printStackTrace();
        // Handle any potential IOException
    }
}


}



